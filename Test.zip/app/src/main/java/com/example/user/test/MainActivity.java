package com.example.user.test;

import android.app.TabActivity;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

@SuppressWarnings("deprecation")
public class MainActivity extends TabActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabHost tabHost = getTabHost();

        TabSpec tabSpecCalendar = tabHost.newTabSpec("CALENDAR").setIndicator("달력");
        tabSpecCalendar.setContent(R.id.tabCalendar);
        tabHost.addTab(tabSpecCalendar);

        TabSpec tabSpecPay = tabHost.newTabSpec("PAY")
                .setIndicator("시급");
        tabSpecPay.setContent(R.id.tabPay);
        tabHost.addTab(tabSpecPay);

        TabSpec tabSpecSetting = tabHost.newTabSpec("SETTING").setIndicator("설정");
        tabSpecSetting.setContent(R.id.tabSetting);
        tabHost.addTab(tabSpecSetting);

        tabHost.setCurrentTab(0);
    }
}