package com.example.testtab;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private TextView thedate;
    final static String KEY_DATE = "date";
    public static String View_DATE = getToday_date();

    private CalendarView mCalendarView;

    TabHost tabhost;
    LinearLayout L1,L2,L3;
    EditText E1,E2,E3;
    TextView T1,T2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        setTitle("가계부 G조");
        init();

        L1=(LinearLayout)findViewById(R.id.L1);
        L2=(LinearLayout)findViewById(R.id.tab1);
        L3=(LinearLayout)findViewById(R.id.tab2);
        E1=(EditText)findViewById(R.id.e1);
        E2=(EditText)findViewById(R.id.e2);
        T1=(TextView)findViewById(R.id.t1);
        thedate = (TextView) findViewById(R.id.date);



        Intent comingIntent = getIntent();
        Log.d(TAG, "getintent OK");
        String date = comingIntent.getStringExtra("date");
        if(!TextUtils.isEmpty(date)){
            View_DATE = date;
            thedate.setText(date);
            Log.d(TAG, "string is not empty");
        } else{
            //date = getToday_date();
            thedate.setText(View_DATE);
        }


        mCalendarView = (CalendarView) findViewById(R.id.calendarView);

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                String date = i + "/" + (i1+1) + "/" + i2;
                Log.d(TAG, "onSelectDayChange: date : "+date);

                Intent intent = new Intent(MainActivity.this,ListEdit.class);
                intent.putExtra("date", date);
                startActivity(intent);
            }
        });


    }
                //삭제 예정 코드
    void onmyclick(View v){
        if(v.getId()==R.id.b1){
            BMI();
        }
    }

    void BMI(){
        String a = E1.getText().toString();
        String b = E2.getText().toString();
        if(a.isEmpty() || b.isEmpty()){
            T1.setText("빈칸이 없이 값을 입력하세요.");
        }
        else {
            Double i = Double.parseDouble(a) * 0.01;
            Double j = Double.parseDouble(b);
            Double bmi = j / (i * i);
            if (bmi < 18.5) {
                T1.setText("체중 부족입니다.");
            } else if (bmi >= 18.5 && bmi <= 22.9) {
                T1.setText("정상 입니다.");
            } else if (bmi >= 23 && bmi <= 24.9) {
                T1.setText("과체중 입니다.");
            } else {
                T1.setText("비만 입니다.");
                T1.setTextColor(Color.RED);
            }
        }
    }

    static public String getToday_date(){
        SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyy/M/d", Locale.KOREA);
        Date currentTime = new Date();
        String Today_day = mSimpleDateFormat.format(currentTime).toString();
        return Today_day;
    }


    void init(){
        tabhost = (TabHost)findViewById(R.id.tabhost);
        tabhost.setup();
        tabhost.addTab(tabhost.newTabSpec("Calendar").setContent(R.id.tab1).setIndicator("Calendar"));
        tabhost.addTab(tabhost.newTabSpec("Pay").setContent(R.id.tab2).setIndicator("Pay"));
        tabhost.addTab(tabhost.newTabSpec("Setting").setContent(R.id.tab3).setIndicator("Setting"));

    }
}
